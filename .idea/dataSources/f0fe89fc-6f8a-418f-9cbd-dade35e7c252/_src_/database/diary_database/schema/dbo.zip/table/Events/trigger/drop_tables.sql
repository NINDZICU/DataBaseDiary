CREATE TRIGGER drop_tables ON Events FOR DELETE
AS BEGIN
  DELETE FROM Places WHERE place_id= (SELECT d.place_id FROM DELETED d INNER JOIN
    (SELECT place_id FROM Places)s1 ON d.place_id=s1.place_id)
  DELETE FROM Reminders WHERE reminder_id=(SELECT place_id FROM DELETED d INNER JOIN(SELECT reminder_id FROM Reminders )s2 ON s2.reminder_id=d.reminder_id);
END