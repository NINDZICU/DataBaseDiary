CREATE PROCEDURE get_friends
          @UserId int, @date date
        AS BEGIN SELECT friend_name FROM select_all WHERE users_id=@UserId AND event_date=@date
        END;