CREATE VIEW select_all
  AS
    SELECT e.event_id,users_id,event_name,event_date,event_begin_time,event_end_time,place_name,description,friend_name
    FROM Events e  LEFT JOIN (SELECT * FROM Places)s1 ON e.place_id=s1.place_id LEFT JOIN
      (SELECT event_id,friend_name FROM friends_group fg LEFT JOIN (SELECT * FROM Friends) s2 ON  fg.friend_id=s2.friend_id) s3 ON s3.event_id=e.event_id