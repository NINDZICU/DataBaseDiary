CREATE PROCEDURE get_notes_today
      @UserId int, @date date
        AS BEGIN SELECT DISTINCT event_id,users_id,event_name,event_date,event_begin_time,event_end_time,place_name,description
                 FROM select_all WHERE users_id=@UserId AND event_date=@date
  END;