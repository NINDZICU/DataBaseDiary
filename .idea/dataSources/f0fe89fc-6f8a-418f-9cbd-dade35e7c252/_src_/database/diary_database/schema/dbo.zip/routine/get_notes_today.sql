CREATE PROCEDURE get_notes_today
      @UserId int, @date date
        AS BEGIN SELECT * FROM select_all WHERE users_id=@UserId AND event_date=@date
  END;